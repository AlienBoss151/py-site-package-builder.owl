# py-site-package-builder.owl (OPI)

**Owl wizard package builder for site: globally manage and install Python project requirements.**

## Install

From PyPI (when published):
```sh
pip install opi
```

Or directly from GitHub:
```sh
pip install git+https://github.com/AlienBoss151/py-site-package-builder.owl.git
```

## Usage

- Place a `requirements.txt` in your project root.
- In your project root, run:
```sh
opi
```
- To display version and log info:
```sh
opi --version
```

## Features

- Creates a new virtual environment (`venv` or `.env`)
- Installs all packages from `requirements.txt`
- Logs each installation to a user log file (`~/.owl_dev/owl_logs/owl_dev_installer.logs`)
- Registers user install (private backend, for analytics and licensing)
- Publisher can globally disable the tool for all users if needed

## License

Apache-2.0